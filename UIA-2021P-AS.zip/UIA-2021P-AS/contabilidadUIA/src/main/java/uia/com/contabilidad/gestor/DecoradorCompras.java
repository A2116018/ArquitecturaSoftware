package uia.com.contabilidad.gestor;

public class DecoradorCompras extends Decorador {
	
	public DecoradorCompras(IGestor gestor)
	{
		super(gestor);
	}
	
	
	public DecoradorCompras()
	{		
	}
	
	public void RegistroCheque()
	{
		super.Print();
	}

}
