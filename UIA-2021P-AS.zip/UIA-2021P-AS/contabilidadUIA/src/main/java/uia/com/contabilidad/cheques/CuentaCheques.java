package uia.com.contabilidad.cheques;

public class CuentaCheques {

}
